import snacksservice from "../services/snacksservice.js"

// let counter = 0;

// function increment() {
//   counter++;
// }

// function decrement() {
//   counter = Math.max(0, counter - 1);
// }

// function updateInput() {
//   $("#input").val(counter);
// }

let counter = 0;

  function updateInput() {
    $("#input").val(counter);
  }

$(document).ready(() => {
    // $("#increment").on("click", function() {
    //     increment();
    //     updateInput();
    //     console.log(counter);
    //   });
  
    //   $("#decrement").on("click", function() {
    //     if ($("#input").val() > 0) {
    //       decrement();
    //     }
    //     updateInput();
    //   });

    $("#increment").on("click",()=>{
        counter++;
        updateInput();
      });
  
      $("#decrement").on("click",()=>{
        if (counter > 0) {
          counter--;
        }
        updateInput();
      });
  
    
    let cart_items=[];
    
  

    snacksservice.getSnacksDetails().then((response) => {
        let itemlist = response.data
        let index=0;
        // console.log(response.data);
        for (let item of itemlist) {
            // console.log(item.snack_img);
            let card = `
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 ms-2 mt-5">
                    <div class="card px-2" style="width: 18rem;">
                        <img src="${item.item_img}" style="width:12rem; height:12rem;" class="card-img-top" alt="#">
                        <div class="card-header">
                            ${item.item_name}
                        </div>
                        <div class="card-body">
                            <p class="card-text">${item.item_content}</p>
                            <p class="card-text">${item.item_price}</p>
                        </div>
                        <div class="d-flex flex-column">
                            <div class="input-group">
                                <button id="decrement" class="decrement" data-index="${index}">-</button>
                                <input type="text" class="quantity" id="input" data-index="${index}" value="0">
                                <button id="increment" class="increment" data-index="${index}">+</button>
                            </div>
                            <button class="btn btn-primary my-2 rounded-2 cart-btn" data-index="${index}">Add to cart</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
            $('.card_container').append(card);
            index++;
        }

        $('.increment').on('click',(e)=>{
            let index = $(e.target).attr('data-index');
            let quantity_element = $(`.quantity[data-index="${index}"]`);
            let value=$(quantity_element).val();
            $(quantity_element).val(Number(value)+1)
        })

        $('.cart-btn').on('click',(e)=>{
            let index = $(e.target).attr('data-index');
            let quantity = $(`.quantity[data-index="${index}"]`).val();
            $(`.quantity[data-index="${index}"]`).val('1');
            let data = itemlist[index];
            data['quantity']=quantity;
           

            let isExisting = false;
            for(let cartItem of cart_items)
                {
                    console.log(cartItem.id+"="+data.id);
                    if(cartItem.id == data.id)
                    {
                        console.log(cart_items);
                        console.log("Cart Quantity"+cartItem['quantity']);
                        console.log("Data Quantity"+data['quantity']);
                        isExisting=true;
                        //cartItem['quantity']= Number(cartItem['quantity']) + Number(data['quantity']);
                    }
                }

            if(!isExisting)
            {
                cart_items.push(data);
            }
            
            $('.summary-items').empty();
            renderItems(cart_items);

    
            let total=0;
            for(let cartItem of  cart_items)
            {
                total+=(Number(cartItem.item_price.replace('₹',''))*Number(cartItem.quantity))
            }

            $('.total-amount').text('₹'+total)
            console.log(total);
        });

        const renderItems = (cart_items) => {
            console.log(cart_items);
            for(let data of cart_items)
            {
                let item = `
                <div class="d-flex justify-content-between px-3 py-2 border-bottom">
                    <span class="item-name-wrap" data-id="${data.id}">${data.item_name}(Qt. ${data.quantity})</span>
                    <span>Rs. ${(Number(data.item_price.replace('₹',''))*Number(data.quantity)).toFixed(2)}</span>
                </div>
                `;

                $('.summary-items').append(item);
            }

            
        }

        $('.decrement').on('click',(e)=>{
            let index = $(e.target).attr('data-index');
            let quantity_element = $(`.quantity[data-index="${index}"]`);
            let value=$(quantity_element).val();
            if(value>0)
            {
                $(quantity_element).val(Number(value)-1)
            }
        })
    })
    .catch((error) => {
        console.log(error);
    })

})
