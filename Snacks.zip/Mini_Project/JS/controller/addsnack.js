import snacksservice from "../services/snacksservice.js"

let counter = 0;

  function updateInput() {
    $("#input").val(counter);
  }

$(document).ready(() => {

    $("#increment").on("click",()=>{
        counter++;
        updateInput();
      });
  
      $("#decrement").on("click",()=>{
        if (counter > 0) {
          counter--;
        }
        updateInput();
      });
  
    
    let cart_items=[];
  

    snacksservice.getSnacksDetails().then((response) => {
        let itemlist = response.data
        let index=0;
        // console.log(response.data);
        for (let item of itemlist) {
            // console.log(item.snack_img);
            let card = `
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 ms-2 mt-5">
                    <div class="card px-2" style="width: 18rem;">
                        <img src="${item.item_img}" style="width:12rem; height:12rem;" class="card-img-top" alt="#">
                        <div class="card-header">
                            ${item.item_name}
                        </div>
                        <div class="card-body">
                            <p class="card-text">${item.item_content}</p>
                            <p class="card-text">${item.item_price}</p>
                        </div>
                        <div class="d-flex flex-column">
                            <div class="input-group">
                                <button id="decrement" class="decrement" data-index="${item.id}">-</button>
                                <input type="text" class="quantity" id="input" data-index="${item.id}" value="0">
                                <button id="increment" class="increment" data-index="${item.id}">+</button>
                            </div>
                            <button class="btn btn-primary my-2 rounded-2 cart-btn" data-index="${item.id}">Add to cart</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
            $('.card_container').append(card);
            index++;
        }

        $('.increment').on('click',(e)=>{
            let index = $(e.target).attr('data-index');
            let quantity_element = $(`.quantity[data-index="${index}"]`);
            let value=$(quantity_element).val();
            $(quantity_element).val(Number(value)+1);
        })

        $('.cart-btn').on('click',(e)=>{
            console.log(cart_items);
            let index = $(e.target).attr('data-index');
            let quantity = $(`.quantity[data-index="${index}"]`).val();
            $(`.quantity[data-index="${index}"]`).val('1');
            
            let data = null;
            for(let i of itemlist)
            {
                if(index == i.id)
                {
                    data=i;
                }
            }
            data['quantity']=quantity;
           

            let isExisting = false;
            for(let cartItem of cart_items)
                {
                    console.log(cartItem.id+"="+data.id);
                    if(cartItem.id == data.id)
                    {
                        console.log(cart_items);
                        console.log("Cart Quantity"+cartItem['quantity']);
                        console.log("Data Quantity"+data['quantity']);
                        isExisting=true;
                        //cartItem['quantity']= Number(cartItem['quantity']) + Number(data['quantity']);
                    }
                }

            if(!isExisting)
            {
                cart_items.push(data);
            }
            
           
            renderItems(cart_items);

    
            let total=0;
            for(let cartItem of  cart_items)
            {
                total+=(Number(cartItem.item_price.replace('₹',''))*Number(cartItem.quantity))
            }

            $('.total-amount').text('₹'+total.toFixed(2))
            console.log(total);
            localStorage.setItem('total_of_snacks',total);
        });

        const updateTotal = (cart_items) => {
            let total=0;
            for(let cartItem of  cart_items)
            {
                total+=(Number(cartItem.item_price.replace('₹',''))*Number(cartItem.quantity))
            }

            $('.total-amount').text('₹'+total.toFixed(2))
            console.log(total);
            localStorage.setItem('total_of_snacks',total);
        }
        const renderItems = (items) => {
            $('.summary-items').empty();
            console.log(cart_items);
            for(let data of cart_items)
            {
                let item = `
                <div class="d-flex justify-content-between px-3 py-2 border-bottom">
                    
                    <div class="d-flex">
                        <button class="clear rounded-2 btn btn-dark" data-id="${data.id}">X</button>&nbsp;&nbsp;
                        <span class="item-name-wrap py-2" data-id="${data.id}">${data.item_name}(Qt. ${data.quantity})</span>
                    </div>
                    <span class="py-2">Rs. ${(Number(data.item_price.replace('₹',''))*Number(data.quantity)).toFixed(2)}</span>
                </div>
                `;

                $('.summary-items').append(item);
            }

            $('.clear').on('click',(e)=>{
                let id = $(e.target).attr('data-id');
                console.log(items);
                for(let cartItem of items)
                    {
                        if(cartItem.id ==id)
                        {
                            cart_items=items.filter(item=>item.id!=id);
                            
                            renderItems(cart_items);
                            updateTotal(cart_items);
                        }
                    }
    
            })
        }

        $('.decrement').on('click',(e)=>{
            let index = $(e.target).attr('data-index');
            let quantity_element = $(`.quantity[data-index="${index}"]`);
            let value=$(quantity_element).val();
            if(value>0)
            {
                $(quantity_element).val(Number(value)-1)
            }
        })

       
    })
    .catch((error) => {
        console.log(error);
    })

    $('#payment').on('click',()=>{
        localStorage.setItem("cart_data",JSON.stringify(cart_items));
    })
})
