class snacksservice
{
    static url='http://localhost:3000/snackslist';
    static async getSnacksDetails()
    {
        return await axios.get(this.url);
    }
    
}
export default snacksservice;